package uniandes.dpoo.taller0.modificacion;

public class Modificacion 
{
 public Modificacion()
 {
  System.out.println("\nHola, mundo!, \nestoy usando objetos!!");	 
 }
}
